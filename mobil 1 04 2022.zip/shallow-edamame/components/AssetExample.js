import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.container}>
      <Image style={styles.logo} source={require('../assets/s2.jpg')} />
      <Text style={styles.paragraph}> Бетти Буп — персонаж рисованных мультфильмов, созданный Максом Флейшером

</Text>
      <Text style={styles.textread}>В 1932—1939 годах Paramount Pictures выпустила в общей сложности 99 короткометражных чёрно-белых мультфильмов о Бетти.
 </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
   textread: {
    margin: 24,
    marginTop: -9,
    fontSize: 12,
    textAlign: 'left',
  },
  paragraph: {
    margin: 24,
    marginTop: 10,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'left',
  },
  logo: {
    height: 128,
    width: 228,
  }
});
